package br.com.aep.hungerless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HungerlessApplication {

	public static void main(String[] args) {
		SpringApplication.run(HungerlessApplication.class, args);
	}

}
